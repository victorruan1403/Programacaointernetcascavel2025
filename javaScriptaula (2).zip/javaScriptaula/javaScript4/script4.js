let numero1 = document.querySelector("#numero1");
let numero2 = document.querySelector("#numero2");
let numero3 = document.querySelector("#numero3");

let calcular1 = document.querySelector("#calcular1");
let calcular2 = document.querySelector("#calcular2");
let calcular3 = document.querySelector("#calcular3");
let calcular4 = document.querySelector("#calcular4");

let resultado1 = document.querySelector("#resultado1");
let resultado2 = document.querySelector("#resultado2");
let resultado3 = document.querySelector("#resultado3");
let resultado4 = document.querySelector("#resultado4");

function aritmética() {
    let valor1 = Number(numero1.value);
    let valor2 =Number(numero2.value);
    let valor3 =Number(numero3.value);
    let total = (valor1 + valor2 + valor3) / 3;
    resultado1.textContent = "Resultado aritmética: " + total;

}

calcular1.onclick = function() {
    aritmética();
};

function ponderada() {
    let valor1 =Number(numero1.value);
    let valor2 =Number(numero2.value);
    let valor3 =Number(numero3.value);
    let total2 = ((valor1 * 3 ) +  (valor2 * 2) + (valor3 * 5)) /10;
    resultado2.textContent ="Resultado ponderada" + total2;
     
}

calcular2.onclick = function(){
    ponderada();

};

function somamedia(){
    let valor1 = Number(numero1.value);
    let valor2 = Number(numero2.value);
    let valor3 = Number(numero3.value);
    let total3 =Number
}
