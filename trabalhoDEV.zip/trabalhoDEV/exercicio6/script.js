let produto = document.querySelector("#produto");
let quantidade = document.querySelector("#quantidade");
let botao6 = document.querySelector("#botao6");
let resultado = document.querySelector("#resultado");

function verificar() {
    let item = (produto.value);
    let qtd = Number(quantidade.value);
    let preco = 0;


    if (item=== "cachorroquente") {
        preco = 11;
    } else if (item=== "bauru") {
        preco = 8.50;
    } else if (item=== "mistoquente") {
        preco = 8;
    } else if (item=== "hamburger") {
        preco =9;
    } else if (item=== "cheeseburger") {
        preco =10;
    } else if (item=== "refrigerante") 
        preco =4.50;

    let total = preco * qtd; 

    resultado.innerHTML = "Item :" + item + "<br> Quantidade :" + qtd 
                           + "<br> Total a Pagar : " + total ; 
        

     

    

}
 
botao6.onclick = function() {
    verificar();
}