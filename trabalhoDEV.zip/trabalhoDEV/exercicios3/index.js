let ano = document.querySelector("#ano");
let tabela = document.querySelector("#tabela");
let btnbotao3 = document.querySelector("#btnbotao3");
let resultado = document.querySelector("#resultado");

function calcular() { 
    let valor1 = Number(ano.value);
    let tabela1 = Number(tabela.value);
    let imposto = 0;

    if (valor1 < 1990 ) {
        imposto = tabela1 * 0.01;

    } else  {
        imposto = tabela1 * 0.015;
    }


resultado.innerHTML = "<h3> o imposto a ser pago é: R$" + imposto + "</h3>" 
}   

btnbotao3.onclick = function () {
    calcular();
}