let valor = document.querySelector("#valor")
let porcentagem = document.querySelector("#porcentagem")
let btncalcular = document.querySelector("#btncalcular")
let resultado = document.querySelector("#resultado")

function Reajustevalor() {
    let valor1 = Number(valor.value);
    let porcentagem1 = Number(porcentagem.value);
    let total = valor1 + (valor1 * (porcentagem1 / 100)); 
    resultado.textContent = "Resultado: " + total.toFixed(2);  
}

btncalcular.onclick = function() {
    Reajustevalor();
}
