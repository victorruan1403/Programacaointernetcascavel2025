let pesoKg = document.querySelector("#pesoKg")
let valorKg = document.querySelector("#valorKg")
let btSomar = document.querySelector("#btSomar")
let resultado = document.querySelector("#resultado")

function multiplicar() {
    let valorMult1 = Number(pesoKg.value)
    let valorMult2 = Number(valorKg.value)
    let resultadoSoma = valorMult1 * valorMult2;
    resultado.textContent = resultadoSoma;
}

btSomar.onclick = function() {
    multiplicar();
}

