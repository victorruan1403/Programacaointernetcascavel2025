let valorPago = document.querySelector("#valorPago")
let valorProduto = document.querySelector("#valorProduto")
let btSomar = document.querySelector("#btSomar")
let resultado = document.querySelector("#resultado")

function subtrair() {
    let valorSomado1 = Number(valorPago.value)
    let valorSomado2 = Number(valorProduto.value)
    let resultadoSoma = valorSomado1 - valorSomado2;
    resultado.textContent = resultadoSoma;
}

btSomar.onclick = function() {
    subtrair();
}






