let numero = document.querySelector("#numero");
let btn = document.querySelector("#btn");
let resultado = document.querySelector("#resultado");


function calcular(){
    let pessoas = Number(numero.value);
    let ovos = pessoas * 2;
    let queijo = pessoas * 50;
   



resultado.innerHTML = "<h3> Será necessarios: " + ovos + " ovos <br>" + 
                        "Será necessario: " + queijo + "  gramas de queijos <br> </h3>";




}


btn.onclick = function() {
    calcular();

}