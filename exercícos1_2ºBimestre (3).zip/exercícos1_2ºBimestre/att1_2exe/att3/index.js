let nmr1 = document.querySelector("#nmr1");
let nmr2 = document.querySelector("#nmr2");
let btn  = document.querySelector("#btn");
let resultado = document.querySelector("#resultado");


function contar(){

let numero1 = Number(nmr1.value);
let numero2 = Number(nmr2.value);


let mais     = numero2 + numero1;
let divisao  = numero2 / numero1;
let menos    = numero2 - numero1;
let vezes   = numero2 * numero1;



resultado.innerHTML = "<h2> Mais: " + mais + "<br>" +
                      "Dividido: " +  divisao + "<br>" +
                      " Diminuir: " + menos + "<br>" +
                      "vezes: " + vezes + "</h3>" 


}




btn.onclick = function(){
    contar();
}























