let vlr1 = document.querySelector("#vlr1");
let vlr2 = document.querySelector("#vlr2");
let btn = document.querySelector("#btn");
let resultado = document.querySelector("#resultado");


function smr(){
let valor1 = Number(vlr1.value);
let valor2 =  Number(vlr2.value);


let calcular = valor1 * valor2;
let erro 

if(valor1 === valor2){
    erro = "Isso não é um retangulo!"
    resultado.textContent = erro
}

else{
    resultado.textContent = calcular
}




}



btn.onclick = function() {
    smr();
}