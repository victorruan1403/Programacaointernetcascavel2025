let valordolar = document.querySelector("#valordolar");
let btn  = document.querySelector("#btn");
let resultado = document.querySelector("#resultado");

function dolar() {
    let cotacao = Number(valordolar.value);

    let aumento1 = cotacao + (cotacao * 0.01);  
    let aumento2 = cotacao + (cotacao * 0.02);  
    let aumento3 = cotacao + (cotacao * 0.05);  
    let aumento4 = cotacao + (cotacao * 0.10); 

   

   resultado.innerHTML = "<h3> O aumento de 1% é :" + aumento1 + "<br>" +
                                "O aumento de 2% é :"  + aumento2 + "<br>" + 
                                "O aumento de 5% é :" + aumento3 + "<br>" +
                                "O aumento de 10% é :" + aumento4 + "</h3>"; 






}
     
      






btn.onclick = function(){
    dolar();
}









