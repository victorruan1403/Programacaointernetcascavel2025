function calcular() {
    let dia = parseInt(document.getElementById("dia").value);
    let mes = parseInt(document.getElementById("mes").value);
  
    if (!dia || dia < 1 || dia > 30 || !mes || mes < 1 || mes > 12) {
      document.getElementById("resultado").innerText = "Informe dia (1-30) e mês (1-12) válidos.";
      return;
    }
  
    let diasPassados = (mes - 1) * 30 + dia;
  
    document.getElementById("resultado").innerText = "Dias desde o início do ano: " + diasPassados;
  }
  