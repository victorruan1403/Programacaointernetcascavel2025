function calcular() {
    let nome = document.getElementById("nome").value;
    let idade = document.getElementById("idade").value;
  
    let dias = idade * 365;
  
    let resultado = document.getElementById("resultado");
    resultado.innerText = nome.toUpperCase() + " VOCÊ JÁ VIVEU " + dias + " DIAS";
  }
  