let cavalo = document.querySelector("#cavalo");
let calcular =document.querySelector("#calcular");
let resultado = document.querySelector("#resultado");

function smr(){
    let cavalo1 = Number(cavalo.value);
    let ferraduras = 4;



    let somar = cavalo1 * ferraduras;


resultado.textContent = somar




}


calcular.onclick = function(){
    smr();
}