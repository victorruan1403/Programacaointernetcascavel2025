function calcular() {
    let paes = document.getElementById("paes").value;
    let broas = document.getElementById("broas").value;
  
    let precoPao = 0.12;
    let precoBroa = 1.50;
  
    let total = (paes * precoPao) + (broas * precoBroa);
    let poupanca = total * 0.10;
  
    let resultado = document.getElementById("resultado");
    resultado.innerText = "Total: R$ " + total.toFixed(2) + "\nPoupança: R$ " + poupanca.toFixed(2);
  }
  