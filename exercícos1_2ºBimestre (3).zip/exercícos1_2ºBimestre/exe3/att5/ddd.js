function calcular() {
    let preco = parseFloat(document.getElementById("preco").value);
    let valor = parseFloat(document.getElementById("valor").value);
  
    if (!preco || preco <= 0 || !valor || valor <= 0) {
      document.getElementById("resultado").innerText = "Por favor, insira valores válidos.";
      return;
    }
  
    let litros = valor / preco;
  
    document.getElementById("resultado").innerText = "Você colocou " + litros.toFixed(2) + " litros no tanque.";
  }
  