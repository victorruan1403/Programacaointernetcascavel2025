let valor = document.querySelector("#valor");
let btnbutton = document.querySelector("#btnbutton"); 
let resultado =document.querySelector("#resultado");

function impar() { 
    let numero1 = Number(valor.value);

    if (numero1 % 2 === 0) { 

    resultado.textContent = "o numero" + numero1 + "é par"; }


   else { resultado.textContent = "o numero" + numero1 + "é impar"; }


}

btnbutton.onclick = function() {
    impar(); 
}















