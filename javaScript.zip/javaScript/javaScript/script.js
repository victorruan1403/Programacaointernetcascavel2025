let nuemero1 = document.querySelector("#numero1");
let nuemero2 = document.querySelector("#numeor2");
let btnSomar = document.querySelector("#Soma")
let Resultado = document.querySelector("#Resultado")

function somar () {
    let numerosomado1 = Number(nuemero1.value);
    let numerosomado2 = Number(numero2.value);
    let resultadosoma = nuemerosmoado1 + numeorosomado2 
    
    resultado.textecontent =resultadosoma;


} 
btnSomar.onclcik = function (){ 
    somar();
}