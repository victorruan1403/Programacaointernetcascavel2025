let valor = document.querySelector("#valor")
let pago = document.querySelector("#pago")
let btnsubtrair = document.querySelector("#btnsubtrair")
let resultado = document.querySelector("#resultado")

function subtrair () {
    let numerovalor1 = Number(valor.value);
    let numeropago2 = Number(pago.value);
    let troco = numerovalor1 * numeropago2;

    resultado.textContent = "troco: " + troco;
}
btnsubtrair.onclick = function (){
    subtrair();
};